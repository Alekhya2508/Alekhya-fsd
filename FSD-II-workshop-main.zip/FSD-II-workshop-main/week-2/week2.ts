console.log("===== WEEK 2: FUNCTIONS IN TYPESCRIPT =====");
console.log("\n--- 1. Parameter Types and Return Types ---");
function add(a: number, b: number): number {
    return a + b;
}
let result: number = add(10, 20);
console.log("First Number: 10");
console.log("Second Number: 20");
console.log("Sum:", result);
console.log("\n--- 2. Optional Parameter ---");
function displayStudent(name: string, age?: number): void {
    console.log("Student Name:", name);
    if (age !== undefined) {
        console.log("Age:", age);
    } else {
        console.log("Age: Not Provided");
    }
}
displayStudent("Moulika", 20);
displayStudent("Anu");
console.log("\n--- 3. Default Parameter ---");
function greet(name: string, message: string = "Welcome to TypeScript"): void {
    console.log(name + ", " + message);
}
greet("Moulika");
greet("Moulika", "Have a great day!");
console.log("\n--- 4. Arrow Function ---");
const multiply = (a: number, b: number): number => {
    return a * b;
};
console.log("Multiplication of 5 and 4:", multiply(5, 4));
console.log("\n--- 5. REST Parameters ---");
function calculateTotal(...numbers: number[]): number {

    let total: number = 0;

    for (let number of numbers) {
        total = total + number;
    }
    return total;
}
console.log(
    "Total of 10, 20, 30 and 40:",
    calculateTotal(10, 20, 30, 40)
);
console.log("\n--- 6. Traditional Function ---");
function square(number: number): number {
    return number * number;
}
console.log("Square using traditional function:", square(6));
console.log("\n--- 7. Converted Arrow Function ---");
const squareArrow = (number: number): number => {
    return number * number;
};
console.log("Square using arrow function:", squareArrow(6));
console.log("\n--- 8. Student Result using Arrow Function ---");
const studentResult = (
    name: string,
    marks: number
): string => {
    if (marks >= 40) {
        return name + " has Passed";
    } else {
        return name + " has Failed";
    }
};
console.log(studentResult("Moulika", 85));
console.log("\n===== WEEK 2 COMPLETED SUCCESSFULLY =====");
